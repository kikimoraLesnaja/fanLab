<div id="botContainer">
        <div id="heroProp">
         <img src="view/img/heroes/ez.png" id="heroImg" alt="avatar">
        Current Hero's properties</div>
            <div id="field">  <br><br><br>Game field</div>
            <div id="heroAll">
                	<div id="heroAllTop">All heroes</div>
                    <div id="heroAllBot"><a href="#">Create hero</a></div>
                    
                    <!---->
                </div>
               <div class="bu"></div>
         </div>
</div>
</body>
</html>

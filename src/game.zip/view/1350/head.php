<!doctype html >
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>1350 Base</title>
<link rel="stylesheet" href="view/1350/css/style1350.css" type="text/css">
<script type="text/javascript" src="js/start.js"></script>
<style type="text/css">


</style>
  
  </head>
<body >
<div id="main">
<div id="cap">
<div id="langs"><a href="#">EE</a> &nbsp;&nbsp;<a href="#">RU</a> &nbsp;&nbsp;<a href="#">EN</a> &nbsp;&nbsp;</div>

cap</div>
<div id ="menu">
	<div id="menuLeft">

<a href="#">About</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="#">Regisration</a>
	</div>
	<div id="menuRight">User <input type="text" class="klient">&nbsp;&nbsp;&nbsp;Password <input type="password" class="klient">&nbsp;&nbsp;&nbsp;<input type="button" value="Go">
	</div>
     <div class="bu"></div>
</div>
<div id="hero">
	<div id="heroProp">
    <img src="view/img/heroes/ez.png" id="heroImg" alt="avatar" >
    Current Hero's properties ... 
    
    </div>
	<div id="heroAllTop">
		<div class="heroAllDet"><a href="#">All heroes</a></div>
		<div class="heroAllDet"><a href="#">Create hero</a></div>
        <div class="bu">
        </div>
	
	</div>

</div>
<div id="field"> <br><br><br> Game field</div>

</div>
</body>
</html>

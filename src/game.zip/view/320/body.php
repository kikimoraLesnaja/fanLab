
<div id="hero">
	<div id="heroProp">
     <img src="view/img/heroes/ez.png" id="heroImg"  alt="avatar" >  Hero's properties</div>
	<div id="heroAllTop">
		<a href="#">Heroes</a>
	
	</div>

</div>
<div id="field"> <br><br><br>Game field</div>

</div>
</body>
</html>

<div id ="menu">

<a href="#">About</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="#">Regisration</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="#">Login</a>
	
</div>
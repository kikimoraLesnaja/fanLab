<?
include('config.php');
//echo "screen - $screenWidth";

include("view/$screenWidth/head.php");
include("view/$screenWidth/menu.php");
include("view/$screenWidth/body.php");


?>
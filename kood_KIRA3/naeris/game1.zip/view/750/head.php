<!doctype html >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>750 Base</title>
<link rel="stylesheet" href="view/750/css/style750.css" type="text/css">

<script type="text/javascript" src="js/start.js"></script>
<style type="text/css">
</style>

  
  </head>
<body >
<div id="main">
<div id="cap">
	<div id="langs">
        <a href="<? echo "?page=$page&lang=ee" ?>">EE</a> &nbsp;&nbsp;
        <a href="<? echo "?page=$page&lang=en" ?>">EN</a> &nbsp;&nbsp;
        <a href="<? echo "?page=$page&lang=ru" ?>">RU</a> &nbsp;&nbsp;
    
    </div>
cap</div>
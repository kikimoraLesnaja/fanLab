<!doctype html >
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>320 Base</title>
<link rel="stylesheet" href="view/320/css/style320.css" type="text/css">
<style type="text/css">

</style>
  
  </head>
<body >
<div id="main">
<div id="cap">
<div id="langs">
<a href="<? echo "?page=$page&lang=ee" ?>">EE</a> &nbsp;&nbsp;
<a href="<? echo "?page=$page&lang=en" ?>">EN</a> &nbsp;&nbsp;
<a href="<? echo "?page=$page&lang=ru" ?>">RU</a> &nbsp;&nbsp;

</div>
cap
</div>
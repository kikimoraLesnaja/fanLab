
<div id="hero">
	<div id="heroProp">
     <img src="view/img/heroes/ez.png" id="heroImg"  alt="avatar" >  Hero's properties</div>
	<div id="heroAllTop">
		<a href="#"><?  echo $heroes ?></a>
	
	</div>

</div>
<div id="field"> <?  include("view/$screenWidth/$page.php"); ?></div>

</div>
</body>
</html>

<div id ="menu">

<a href="?page=about&lang=<? echo $lang ?>"><?  echo $about ?></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="?page=reg&lang=<? echo $lang ?>"><?  echo $reg ?></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="#">Login</a>
	
</div>
<?
echo $about;
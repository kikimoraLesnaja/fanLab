<div id ="menu">
	<div id="menuLeft">

<a href="?page=about&lang=<? echo $lang ?>"><?  echo $about ?></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	<a href="?page=reg&lang=<? echo $lang ?>"><?  echo $reg ?></a>
	</div>
	<div id="menuRight"><?  echo $user ?> <input type="text" class="klient">&nbsp;&nbsp;&nbsp;<?  echo $pass ?> 
    <input type="password" class="klient">&nbsp;&nbsp;&nbsp;<input type="button" value="Go">
	</div>
     <div class="bu"></div>
</div>
<?
include("controller/pageController.php");

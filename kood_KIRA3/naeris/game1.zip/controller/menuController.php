<?


$about=tr('about');
$reg=tr('reg');
$user=tr('user');
$pass=tr('pass');

/*$about=tr('about');
$about=tr('about');

$contact=tr('contact');

*/
?>
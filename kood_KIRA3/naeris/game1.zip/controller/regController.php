<?

//include("controller/pageController.php");

$nick=tr('nick');
$pass=tr('pass');
$repeat_pass=tr('repeat_pass');
$email=tr('email');

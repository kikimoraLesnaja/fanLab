<?


$heroes=tr('heroes');
$allhero=tr('allhero');
$creahero=tr('creahero');

<?

/*
$img0 =getImg("img/$page",0);

$img1 =getImg("img/$page",1);
$img2 =getImg("img/$page",2);

*/

//----------------------------------------- CAP AND TEEXT OF PAGE -----------------------------------------------
/*
$SEL="SELECT cap_$lang as cap, $lang as mess FROM pages WHERE name='$page'";

$db->query($SEL);

$resc=$db->assoc_array();

$pageCap=convertFromBase($resc[0]['cap']);

$pageMess=convertFromBase($resc[0]['mess']);
*/


//*************************************** *******************************************************

